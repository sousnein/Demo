﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2.Entities
{
    public partial class Order
    {
        public string PickupPointString
        {
            get
            {
                if (OrderPickupPointNavigation.PickupPointHouseNumber != null)
                    return OrderPickupPointNavigation.PickupPointIndex + ", г. " + OrderPickupPointNavigation.PickupPointCity
                    + ", ул. " + OrderPickupPointNavigation.PickupPointStreet +
                    ", д. " + OrderPickupPointNavigation.PickupPointHouseNumber;
                else
                    return OrderPickupPointNavigation.PickupPointIndex + ", г. " + OrderPickupPointNavigation.PickupPointCity
                    + ", ул. " + OrderPickupPointNavigation.PickupPointStreet;
            }
        }

        public string OrderUserString
        {
            get
            {
                if (OrderUser != null)
                    return OrderUserNavigation.UserSurname + " " + OrderUserNavigation.UserName + " " +
                        OrderUserNavigation.UserPatronymic;
                else
                    return "";
            }
        }

        public string DateOrder
        {
            get
            {
                return OrderDate.Date.ToShortDateString();
            }
        }

        public string DeliveryDateOrder
        {
            get
            {
                return OrderDeliveryDate.Date.ToShortDateString();
            }
        }
    }
}
