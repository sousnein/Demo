﻿using System;
using System.Collections.Generic;

namespace Demo2.Entities
{
    public partial class Category
    {
        public Category()
        {
            Products = new HashSet<Product>();
        }

        public int CategoryId { get; set; }
        public string CategoryValue { get; set; } = null!;

        public virtual ICollection<Product> Products { get; set; }
    }
}
