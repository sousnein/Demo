﻿using System;
using System.Collections.Generic;

namespace Demo2.Entities
{
    public partial class Order
    {
        public Order()
        {
            OrderProducts = new HashSet<OrderProduct>();
        }

        public int OrderId { get; set; }
        public int? OrderUser { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime OrderDeliveryDate { get; set; }
        public int OrderPickupPoint { get; set; }
        public int OrderStatus { get; set; }
        public int OrderPickupCode { get; set; }

        public virtual PickupPoint OrderPickupPointNavigation { get; set; } = null!;
        public virtual StatusOrder OrderStatusNavigation { get; set; } = null!;
        public virtual User? OrderUserNavigation { get; set; }
        public virtual ICollection<OrderProduct> OrderProducts { get; set; }
    }
}
