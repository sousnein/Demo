﻿using System;
using System.Collections.Generic;

namespace Demo2.Entities
{
    public partial class OrderProduct
    {
        public int OrderProductId { get; set; }
        public int OrderId { get; set; }
        public string OrderProductArticleNumber { get; set; } = null!;
        public int OrderProductQuantity { get; set; }

        public virtual Order Order { get; set; } = null!;
        public virtual Product OrderProductArticleNumberNavigation { get; set; } = null!;
    }
}
