﻿using System;
using System.Collections.Generic;

namespace Demo2.Entities
{
    public partial class ProductAvailability
    {
        public ProductAvailability()
        {
            Products = new HashSet<Product>();
        }

        public int ProductAvailabilityId { get; set; }
        public string ProductAvailabilityValue { get; set; } = null!;

        public virtual ICollection<Product> Products { get; set; }
    }
}
