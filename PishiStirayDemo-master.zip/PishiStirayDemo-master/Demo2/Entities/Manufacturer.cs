﻿using System;
using System.Collections.Generic;

namespace Demo2.Entities
{
    public partial class Manufacturer
    {
        public Manufacturer()
        {
            Products = new HashSet<Product>();
        }

        public int ManufacturerId { get; set; }
        public string ManufacturerValue { get; set; } = null!;

        public virtual ICollection<Product> Products { get; set; }
    }
}
