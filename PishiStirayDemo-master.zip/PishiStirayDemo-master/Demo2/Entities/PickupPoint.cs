﻿using System;
using System.Collections.Generic;

namespace Demo2.Entities
{
    public partial class PickupPoint
    {
        public PickupPoint()
        {
            Orders = new HashSet<Order>();
        }

        public int PickupPointId { get; set; }
        public string PickupPointIndex { get; set; } = null!;
        public string PickupPointCity { get; set; } = null!;
        public string PickupPointStreet { get; set; } = null!;
        public string? PickupPointHouseNumber { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
    }
}
