﻿using System;
using System.Collections.Generic;

namespace Demo2.Entities
{
    public partial class Product
    {
        public Product()
        {
            OrderProducts = new HashSet<OrderProduct>();
        }

        public string ProductArticleNumber { get; set; } = null!;
        public string ProductName { get; set; } = null!;
        public int ProductUnit { get; set; }
        public decimal ProductCost { get; set; }
        public int? ProductPossibleDiscount { get; set; }
        public int ProductManufacturer { get; set; }
        public int? ProductSupplier { get; set; }
        public int ProductCategory { get; set; }
        public double? ProductDiscountAmount { get; set; }
        public int ProductQuantityInStock { get; set; }
        public string ProductDescription { get; set; } = null!;
        public byte[]? ProductPhoto { get; set; }
        public int ProductAvailability { get; set; }

        public virtual ProductAvailability ProductAvailabilityNavigation { get; set; } = null!;
        public virtual Category ProductCategoryNavigation { get; set; } = null!;
        public virtual Manufacturer ProductManufacturerNavigation { get; set; } = null!;
        public virtual Supplier? ProductSupplierNavigation { get; set; }
        public virtual Unit ProductUnitNavigation { get; set; } = null!;
        public virtual ICollection<OrderProduct> OrderProducts { get; set; }
    }
}
